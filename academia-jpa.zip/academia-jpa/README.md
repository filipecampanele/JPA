# Academia JPA — Conhecendo Spring Data JPA na prática com Java

API RESTful de uma **academia de ginástica** para praticar mapeamento objeto-relacional (ORM) com Spring Data JPA.

## Tecnologias
Java 17 · Spring Boot 3.3 · Spring Data JPA · Bean Validation · H2 / PostgreSQL · Lombok · Maven

## Como rodar
```bash
mvn spring-boot:run
```
Por padrão usa **H2 em memória** (console em `http://localhost:8080/h2-console`, JDBC URL `jdbc:h2:mem:academia`, user `sa`, sem senha).

Para usar PostgreSQL (crie antes o banco `academia`):
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=postgres
```

## Modelo de dados
- **Aluno** (1) — (N) **AvaliacaoFisica**
- **Aluno** (1) — (1) **Matricula**

## Endpoints
| Método | Rota | Descrição |
|---|---|---|
| POST | `/alunos` | Cria aluno |
| GET | `/alunos` | Lista (filtros: `?dataDeNascimento=2000-01-31`, `?bairro=Centro`) |
| GET | `/alunos/busca?nome=ana` | Busca por trecho do nome |
| GET | `/alunos/{id}` | Detalha aluno |
| GET | `/alunos/avaliacoes/{id}` | Avaliações do aluno |
| PUT | `/alunos/{id}` | Atualiza aluno |
| DELETE | `/alunos/{id}` | Remove aluno (e suas avaliações) |
| POST/GET/PUT/DELETE | `/avaliacoes` | CRUD de avaliações (`?pesoMinimo=70`) |
| POST/GET/DELETE | `/matriculas` | Matrículas (`?bairro=Centro`) |

### Exemplos
```json
POST /alunos
{ "nome": "Maria Silva", "cpf": "529.982.247-25", "bairro": "Centro", "dataDeNascimento": "1995-04-20" }

POST /avaliacoes
{ "alunoId": 1, "peso": 62.5, "altura": 1.65 }

POST /matriculas
{ "alunoId": 1 }
```

## Conceitos de JPA aplicados
- Anotações: `@Entity`, `@Table`, `@Id`, `@GeneratedValue`, `@Column`, `@OneToMany`, `@ManyToOne`, `@OneToOne`, `@JoinColumn`
- CRUD com `JpaRepository`
- Validação: `@NotBlank`, `@Size`, `@CPF`, `@Past`, `@DecimalMin`, tratada em `@RestControllerAdvice`
- Consultas avançadas: *query methods* (`findByBairro`, `findByNomeContainingIgnoreCase`) e JPQL com `@Query`
