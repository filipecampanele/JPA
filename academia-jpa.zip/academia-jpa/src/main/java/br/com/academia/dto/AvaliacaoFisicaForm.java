package br.com.academia.dto;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AvaliacaoFisicaForm {

    @NotNull(message = "Preencha o campo corretamente.")
    @Positive(message = "O Id do aluno precisa ser positivo.")
    private Long alunoId;

    @NotNull(message = "Preencha o campo corretamente.")
    @DecimalMin(value = "30.0", message = "'${validatedValue}' é um peso inválido (mínimo {value}).")
    private Double peso;

    @NotNull(message = "Preencha o campo corretamente.")
    @DecimalMin(value = "1.0", message = "'${validatedValue}' é uma altura inválida (mínimo {value}).")
    private Double altura;
}
