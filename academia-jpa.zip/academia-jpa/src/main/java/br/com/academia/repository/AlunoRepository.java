package br.com.academia.repository;

import br.com.academia.entity.Aluno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface AlunoRepository extends JpaRepository<Aluno, Long> {

    // Query methods (derivadas do nome do método)
    List<Aluno> findByBairro(String bairro);

    List<Aluno> findByNomeContainingIgnoreCase(String nome);

    boolean existsByCpf(String cpf);

    // JPQL
    @Query("SELECT a FROM Aluno a WHERE a.dataDeNascimento = :dataDeNascimento")
    List<Aluno> findByDataDeNascimento(@Param("dataDeNascimento") LocalDate dataDeNascimento);

    // JPQL com intervalo, ordenado
    @Query("SELECT a FROM Aluno a WHERE a.dataDeNascimento BETWEEN :inicio AND :fim ORDER BY a.nome")
    List<Aluno> findNascidosEntre(@Param("inicio") LocalDate inicio, @Param("fim") LocalDate fim);
}
