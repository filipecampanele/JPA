package br.com.academia.repository;

import br.com.academia.entity.AvaliacaoFisica;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AvaliacaoFisicaRepository extends JpaRepository<AvaliacaoFisica, Long> {

    List<AvaliacaoFisica> findByAlunoId(Long alunoId);

    // JPQL: avaliações com peso mínimo, do maior para o menor
    @Query("SELECT av FROM AvaliacaoFisica av WHERE av.peso >= :peso ORDER BY av.peso DESC")
    List<AvaliacaoFisica> findComPesoMinimo(@Param("peso") double peso);
}
