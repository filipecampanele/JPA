package br.com.academia.repository;

import br.com.academia.entity.Matricula;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MatriculaRepository extends JpaRepository<Matricula, Long> {

    boolean existsByAlunoId(Long alunoId);

    // JPQL navegando pela relação: matrículas de alunos de um bairro
    @Query("SELECT m FROM Matricula m WHERE m.aluno.bairro = :bairro")
    List<Matricula> findAlunosMatriculadosBairro(@Param("bairro") String bairro);
}
