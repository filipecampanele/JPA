package br.com.academia.service;

import br.com.academia.dto.AlunoForm;
import br.com.academia.dto.AlunoUpdateForm;
import br.com.academia.entity.Aluno;
import br.com.academia.entity.AvaliacaoFisica;
import br.com.academia.exception.RecursoNaoEncontradoException;
import br.com.academia.exception.RegraDeNegocioException;
import br.com.academia.repository.AlunoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class AlunoService {

    private final AlunoRepository repository;

    public AlunoService(AlunoRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public Aluno create(AlunoForm form) {
        if (repository.existsByCpf(form.getCpf())) {
            throw new RegraDeNegocioException("CPF '" + form.getCpf() + "' já cadastrado.");
        }
        Aluno aluno = new Aluno();
        aluno.setNome(form.getNome());
        aluno.setCpf(form.getCpf());
        aluno.setBairro(form.getBairro());
        aluno.setDataDeNascimento(form.getDataDeNascimento());
        return repository.save(aluno);
    }

    @Transactional(readOnly = true)
    public Aluno get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Aluno " + id + " não encontrado."));
    }

    @Transactional(readOnly = true)
    public List<Aluno> getAll(LocalDate dataDeNascimento, String bairro) {
        if (dataDeNascimento != null) {
            return repository.findByDataDeNascimento(dataDeNascimento);
        }
        if (bairro != null && !bairro.isBlank()) {
            return repository.findByBairro(bairro);
        }
        return repository.findAll();
    }

    @Transactional(readOnly = true)
    public List<Aluno> buscarPorNome(String nome) {
        return repository.findByNomeContainingIgnoreCase(nome);
    }

    @Transactional(readOnly = true)
    public List<AvaliacaoFisica> getAllAvaliacaoFisicaId(Long id) {
        return get(id).getAvaliacoes();
    }

    @Transactional
    public Aluno update(Long id, AlunoUpdateForm form) {
        Aluno aluno = get(id);
        aluno.setNome(form.getNome());
        aluno.setBairro(form.getBairro());
        aluno.setDataDeNascimento(form.getDataDeNascimento());
        return repository.save(aluno);
    }

    @Transactional
    public void delete(Long id) {
        repository.delete(get(id));
    }
}
