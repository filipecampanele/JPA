package br.com.academia.service;

import br.com.academia.dto.AvaliacaoFisicaForm;
import br.com.academia.dto.AvaliacaoFisicaUpdateForm;
import br.com.academia.entity.Aluno;
import br.com.academia.entity.AvaliacaoFisica;
import br.com.academia.exception.RecursoNaoEncontradoException;
import br.com.academia.repository.AlunoRepository;
import br.com.academia.repository.AvaliacaoFisicaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AvaliacaoFisicaService {

    private final AvaliacaoFisicaRepository repository;
    private final AlunoRepository alunoRepository;

    public AvaliacaoFisicaService(AvaliacaoFisicaRepository repository, AlunoRepository alunoRepository) {
        this.repository = repository;
        this.alunoRepository = alunoRepository;
    }

    @Transactional
    public AvaliacaoFisica create(AvaliacaoFisicaForm form) {
        Aluno aluno = alunoRepository.findById(form.getAlunoId())
                .orElseThrow(() -> new RecursoNaoEncontradoException("Aluno " + form.getAlunoId() + " não encontrado."));
        AvaliacaoFisica av = new AvaliacaoFisica();
        av.setAluno(aluno);
        av.setPeso(form.getPeso());
        av.setAltura(form.getAltura());
        return repository.save(av);
    }

    @Transactional(readOnly = true)
    public AvaliacaoFisica get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Avaliação " + id + " não encontrada."));
    }

    @Transactional(readOnly = true)
    public List<AvaliacaoFisica> getAll(Double pesoMinimo) {
        if (pesoMinimo != null) {
            return repository.findComPesoMinimo(pesoMinimo);
        }
        return repository.findAll();
    }

    @Transactional
    public AvaliacaoFisica update(Long id, AvaliacaoFisicaUpdateForm form) {
        AvaliacaoFisica av = get(id);
        av.setPeso(form.getPeso());
        av.setAltura(form.getAltura());
        return repository.save(av);
    }

    @Transactional
    public void delete(Long id) {
        repository.delete(get(id));
    }
}
