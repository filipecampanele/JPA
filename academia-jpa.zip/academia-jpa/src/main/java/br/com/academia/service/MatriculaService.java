package br.com.academia.service;

import br.com.academia.dto.MatriculaForm;
import br.com.academia.entity.Aluno;
import br.com.academia.entity.Matricula;
import br.com.academia.exception.RecursoNaoEncontradoException;
import br.com.academia.exception.RegraDeNegocioException;
import br.com.academia.repository.AlunoRepository;
import br.com.academia.repository.MatriculaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class MatriculaService {

    private final MatriculaRepository repository;
    private final AlunoRepository alunoRepository;

    public MatriculaService(MatriculaRepository repository, AlunoRepository alunoRepository) {
        this.repository = repository;
        this.alunoRepository = alunoRepository;
    }

    @Transactional
    public Matricula create(MatriculaForm form) {
        Aluno aluno = alunoRepository.findById(form.getAlunoId())
                .orElseThrow(() -> new RecursoNaoEncontradoException("Aluno " + form.getAlunoId() + " não encontrado."));
        if (repository.existsByAlunoId(aluno.getId())) {
            throw new RegraDeNegocioException("Aluno " + aluno.getId() + " já está matriculado.");
        }
        Matricula m = new Matricula();
        m.setAluno(aluno);
        return repository.save(m);
    }

    @Transactional(readOnly = true)
    public Matricula get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Matrícula " + id + " não encontrada."));
    }

    @Transactional(readOnly = true)
    public List<Matricula> getAll(String bairro) {
        if (bairro != null && !bairro.isBlank()) {
            return repository.findAlunosMatriculadosBairro(bairro);
        }
        return repository.findAll();
    }

    @Transactional
    public void delete(Long id) {
        repository.delete(get(id));
    }
}
